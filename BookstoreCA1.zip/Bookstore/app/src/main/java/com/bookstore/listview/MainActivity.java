package com.bookstore.listview;

import android.content.Intent;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity implements BookListFragment.ItemListener {

    private boolean mTwoPane;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTwoPane = (findViewById(R.id.book_details_two_pane) != null);
        if (mTwoPane) {
            List<Book> books = Model.getInstance().getBooks();
            if (!books.isEmpty()) {
                Book book = Model.getInstance().getBooks().get(0);
                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                ft.add(R.id.book_details_two_pane, BookDetailFragment.newInstance(book.getId()));
                ft.commit();
            }
        }
    }

    @Override
    public void itemSelected(Book b) {
        if (mTwoPane) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();

            ft.replace(R.id.book_details_two_pane, BookDetailFragment.newInstance(b.getId()));
            ft.commit();
        }
        else {
            Intent intent = new Intent(this, BookDetailActivity.class);
            intent.putExtra(BookDetailFragment.EXTRA_BOOK_ID, b.getId());

            startActivity(intent);
        }
    }

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        MenuInflater inflater = getMenuInflater();
//        inflater.inflate(R.menu.action_bar_menu, menu);
//
//                return true;
//
//        }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        switch(item.getItemId()){
//            case R.id.action_cart:
//                Toast.makeText(this, "Cart selected", Toast.LENGTH_SHORT).show();
//
//                return true;
//
//            case R.id.action_more:
//                Toast.makeText(this, "More selected", Toast.LENGTH_SHORT).show();
//                return true;
//
//                default:
//                    return super.onOptionsItemSelected(item);
//        }
//    }
}
