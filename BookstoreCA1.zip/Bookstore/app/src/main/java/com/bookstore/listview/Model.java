package com.bookstore.listview;

import java.util.ArrayList;
import java.util.List;

public class Model {

    private static Model instance = null;
    private final List<Book> mBooks;

    public static Model getInstance() {
        if (instance == null) {
            instance = new Model();
        }
        return instance;
    }

    private Model() {
        mBooks = new ArrayList<>();
        getBooks().add(new Book(2, "Beginning PHP 5.3", "Matt Doyle", "9780470413968", 2009, 36.40, "https://images-na.ssl-images-amazon.com/images/I/51lClQycoYL._SX397_BO1,204,203,200_.jpg"));
        getBooks().add(new Book(3, "Beginning To Learn JavaScript, 5th Edition", "Jeremy McPeak", "9781118903339", 2015, 40.90, "https://images-na.ssl-images-amazon.com/images/I/61%2BYj15dlEL._SY346_.jpg"));
        getBooks().add(new Book(1, "Learning PHP: A Gentle Introduction to the Web's Most Popular Language", "David Sklar", "9781491933572", 2016, 41.99, "https://images-na.ssl-images-amazon.com/images/I/51jTFfBB8mL._SY346_.jpg"));
    }

    public List<Book> getBooks() {
        return mBooks;
    }

    public Book findBookById(int book_id) {
        Book book = null;
        for (Book b : mBooks) {
            if (b.getId() == book_id) {
                book = b;
                break;
            }
        }
        return book;
    }
}
