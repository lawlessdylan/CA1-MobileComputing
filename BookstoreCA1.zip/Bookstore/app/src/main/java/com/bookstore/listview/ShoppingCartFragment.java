package com.bookstore.listview;


import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class ShoppingCartFragment extends Fragment {

    public interface ItemListener {
        public void itemSelected(ShoppingCartItem s);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ShoppingCartFragment.ItemListener){
            this.sActivity = (ShoppingCartActivity) context;
        }
    }

    private ShoppingCartActivity sActivity = null;

    public ShoppingCartFragment() {}

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {

        super.onViewCreated(view, savedInstanceState);

        RecyclerView mRecyclerView = view.findViewById(R.id.book_list_view);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(sActivity);
        mRecyclerView.setLayoutManager(mLayoutManager);

        List<ShoppingCartItem> items = ShoppingCart.getInstance().getItems();
        RecyclerView.Adapter adapter = new ShoppingCartAdapter(sActivity, items);
        mRecyclerView.setAdapter(adapter);
    }

    }
