package com.bookstore.listview;

import android.content.Intent;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class BookDetailActivity extends AppCompatActivity {

    private Book book;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_detail);

        Intent intent = getIntent();
        int book_id = intent.getIntExtra(BookDetailFragment.EXTRA_BOOK_ID, -1);

        this.book = Model.getInstance().findBookById(book_id);

        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.add(R.id.book_details_one_pane, BookDetailFragment.newInstance(book_id));
        ft.commit();
    }
    protected void add(View v) {

        ShoppingCart.getInstance().add(book, 1);

        Toast.makeText(this, "Added to cart " + book.getTitle(), Toast.LENGTH_LONG).show();

        Intent intent = new Intent(BookDetailActivity.this, ShoppingCartActivity.class);
        startActivity(intent);

    }


}
